#include <stdio.h>
int main() 
{
	int a = 5;
	int b = 5;
	int x = b - a;
	int y = c + 11;
	int soma = a + b;
	int a = b + x * y;
	return 0;
}   